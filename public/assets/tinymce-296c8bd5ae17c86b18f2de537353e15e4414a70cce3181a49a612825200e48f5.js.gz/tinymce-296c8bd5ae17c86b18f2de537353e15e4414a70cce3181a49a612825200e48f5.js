(function() {
  $(document).ready(function() {
    return window.scrollTo(0, 0);
  });

}).call(this);
